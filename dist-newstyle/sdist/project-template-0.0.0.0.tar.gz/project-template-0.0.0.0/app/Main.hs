module Main where

import MyProj

main :: IO ()
main = do
  putStrLn "Hello World!"
  runMyProj
