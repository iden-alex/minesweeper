module MyProj
    ( runField
    ) where

import System.Random
import System.Io
import Data.Map
import Data.Set

type Field = Map Cell Cellstate
type Cell = (Int, Int)
type Mines = Set Cell

data CellState = Opened Int
                | Mine
                | Flag

size_row :: Int
size_row = 10

size_col :: Int
size_col = 10

range :: (Int, Int)
range = (0, 100)


runField :: IO()
runField = putStrln "Test"